
// server/app.js
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const productRoutes = require('./routes/productRoutes');
const userRoutes = require('./routes/userRoutes');
const { connectToDB, getUsers, getProducts } = require('./db');

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

// Middlewares
app.use(express.json());
app.use(cors());

// Connexion à la base Azure SQL
connectToDB();

// Routes API
app.use('/api/products', productRoutes);
app.use('/api/users', userRoutes);

// Route de test
app.get('/', (req, res) => {
  res.send('Bienvenue sur l\'API du e-commerce avec Azure SQL Database');
});

// Route pour récupérer tous les utilisateurs
app.get('/api/users', async (req, res) => {
  const users = await getUsers();
  res.json(users);
});

// Route pour récupérer tous les produits
app.get('/api/products', async (req, res) => {
  const products = await getProducts();
  res.json(products);
});

// Lancer le serveur
app.listen(PORT, () => {
  console.log(`✅ Serveur lancé sur le port ${PORT}`);
});

