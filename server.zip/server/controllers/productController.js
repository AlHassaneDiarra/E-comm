// server/controllers/productController.js
const { sql } = require('../db');

exports.getAllProducts = async (req, res) => {
  try {
    const result = await sql.query`SELECT * FROM Products`;
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.createProduct = async (req, res) => {
  const { name, description, price, imageUrl } = req.body;
  try {
    await sql.query`
      INSERT INTO Products (name, description, price, imageUrl, createdAt)
      VALUES (${name}, ${description}, ${price}, ${imageUrl}, GETDATE())
    `;
    res.status(201).json({ message: 'Produit créé avec succès' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};
