// server/controllers/userController.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { sql } = require('../db');

exports.register = async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    await sql.query`
      INSERT INTO Users (username, email, password, createdAt)
      VALUES (${username}, ${email}, ${hashedPassword}, GETDATE())
    `;
    res.status(201).json({ message: 'Utilisateur créé avec succès' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    // Récupérer l'utilisateur via une requête SQL
    const result = await sql.query`
      SELECT * FROM Users WHERE email = ${email}
    `;
    const user = result.recordset[0];
    if (!user) return res.status(400).json({ error: 'Utilisateur non trouvé' });
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).json({ error: 'Identifiants invalides' });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
