const sql = require("mssql");
require("dotenv").config();

const config = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_HOST,
    database: process.env.DB_NAME,
    port: parseInt(process.env.DB_PORT, 10),
    options: {
        encrypt: process.env.DB_ENCRYPT === "true", 
        trustServerCertificate: process.env.DB_TRUST_CERTIFICATE === "true"
    }
};

async function connectToDB() {
    try {
        await sql.connect(config);
        console.log("✅ Connexion à la base de données réussie !");
    } catch (error) {
        console.error("❌ Erreur de connexion à la base de données :", error);
    }
}

module.exports = { connectToDB, sql };
